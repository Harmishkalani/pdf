
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class _Default : System.Web.UI.Page
{
    string connStr = ConfigurationManager.ConnectionStrings["CrudConn"].ConnectionString;
    static int currentId = -1;
    SqlDataAdapter da;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadCourses();
            LoadStudents();
        }
    }

    private void LoadCourses()
    {
        using (SqlConnection cn = new SqlConnection(connStr))
        {
            da = new SqlDataAdapter("SELECT * FROM Courses", cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            ddlCourse.DataSource = dt;
            ddlCourse.DataTextField = "course_name";
            ddlCourse.DataValueField = "course_name";
            ddlCourse.DataBind();
            ddlCourse.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--Select Course--", ""));
        }
    }

    private void LoadStudents()
    {
        using (SqlConnection cn = new SqlConnection(connStr))
        {
            da = new SqlDataAdapter("SELECT * FROM Student", cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }

    protected void btnInsert_Click(object sender, EventArgs e)
    {
        if (!string.IsNullOrWhiteSpace(txtName.Text) && ddlCourse.SelectedIndex != 0)
        {
            using (SqlConnection cn = new SqlConnection(connStr))
            {
                string sql = "INSERT INTO Student (sname, course) VALUES (@name, @course)";
                SqlCommand cmd = new SqlCommand(sql, cn);
                cmd.Parameters.AddWithValue("@name", txtName.Text);
                cmd.Parameters.AddWithValue("@course", ddlCourse.SelectedValue);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            Clear();
            LoadStudents();
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (currentId != -1)
        {
            using (SqlConnection cn = new SqlConnection(connStr))
            {
                string sql = "UPDATE Student SET sname = @name, course = @course WHERE id = @id";
                SqlCommand cmd = new SqlCommand(sql, cn);
                cmd.Parameters.AddWithValue("@name", txtName.Text);
                cmd.Parameters.AddWithValue("@course", ddlCourse.SelectedValue);
                cmd.Parameters.AddWithValue("@id", currentId);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            Clear();
            LoadStudents();
        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        if (currentId != -1)
        {
            using (SqlConnection cn = new SqlConnection(connStr))
            {
                string sql = "DELETE FROM Student WHERE id = @id";
                SqlCommand cmd = new SqlCommand(sql, cn);
                cmd.Parameters.AddWithValue("@id", currentId);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            Clear();
            LoadStudents();
        }
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView1.SelectedRow;
        currentId = Convert.ToInt32(row.Cells[0].Text);
        txtName.Text = row.Cells[1].Text;
        ddlCourse.SelectedValue = row.Cells[2].Text;
        btnUpdate.Enabled = true;
        btnDelete.Enabled = true;
    }

    private void Clear()
    {
        txtName.Text = "";
        ddlCourse.SelectedIndex = 0;
        currentId = -1;
        btnUpdate.Enabled = false;
        btnDelete.Enabled = false;
    }
}
